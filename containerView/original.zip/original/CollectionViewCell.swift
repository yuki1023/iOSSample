//
//  CollectionViewCell.swift
//  original
//
//  Created by 黒部麻由子 on 2020/09/07.
//  Copyright © 2020 mayukokurobe. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var CorporateNameLabel : UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
